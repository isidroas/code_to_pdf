#!/bin/python3
import argparse
import logging
import subprocess
import sys
from enum import Enum
from pathlib import Path
from typing import List, Optional
from datetime import datetime

LOG = logging.getLogger(__name__)
# logging.basicConfig(level=logging.DEBUG)

__all__ = ['add_arguments', 'walkfind', 'Sort', 'WalkFind']

def add_arguments(parser):
    parser.add_argument(
        "targets",
        help="path of the file or directory to search. If is '-', the list is taken from stdin bypassing this program",
        metavar="target",
        type=Path,
        nargs="+",
    )
    parser.add_argument(
        "--exclude-file",
        help="It accepts glob",
        dest="exclude_files",
        default=[],
        action="append",
    )
    parser.add_argument(
        "--include-file",
        help="It accepts glob",
        dest="include_files",
        default=[],
        action="append",
    )
    parser.add_argument(
        "--exclude-dir",
        help="It will exclude its content and of all the depth of subdirs. It accepts glob",
        dest="exclude_dirs",
        default=[],
        action="append",
    )
    parser.add_argument("--git-tracked", action="store_true")
    parser.add_argument("--empty", action=argparse.BooleanOptionalAction)
    parser.add_argument("--max-depth", type=int)
    parser.add_argument("--executable", action=argparse.BooleanOptionalAction)
    parser.add_argument("--binary", action=argparse.BooleanOptionalAction)
    parser.add_argument("--also-dirs", action="store_true")
    parser.add_argument("--only-dirs", action="store_true")
    parser.add_argument(
        "--sort",
        type=Sort,
        choices=list(Sort),
        action="append",
        default=[],
    )
    parser.add_argument("--size-bigger", type=int)
    parser.add_argument("--size-lower", type=int)
    parser.add_argument("--changed-within", type=float)
    parser.add_argument("--change-older-than", type=float)

def get_arguments():
    parser = argparse.ArgumentParser(
        description="fd/find alternative. Currently only returns files, not directories"
    )
    add_arguments(parser)
    options = vars(parser.parse_args())
    targets = options.pop("targets")
    return targets, options


class Sort(Enum):
    ALPHA = "alpha"
    ALPHA_INV = "alpha_inv"
    SIZE = "size"
    SIZE_INV = "size_inv"
    MODIFICATION = "modification"
    MODIFICATION_INV = "modification_inv"
    DIRS_FIRST = "dirs_first"
    FILES_FIRST = "files_first"


class WalkFind:
    def __init__(
        self,
        targets: List[Path],
        exclude_dirs: List[str] = [],
        exclude_files: List[str] = [],
        include_files: List[str] = [],
        git_tracked=False,
        empty: Optional[bool] = None,
        max_depth: Optional[int] = None,
        executable: Optional[bool] = None,
        binary: Optional[bool] = None,
        also_dirs: bool = False,
        only_dirs: bool = False,
        sort: Sort = None,
        size_bigger:int = None,
        size_lower:int = None,
        changed_within:float = None,
        change_older_than:float = None,
    ):
        """
        `empty`, `executable` and `binary` are trileans
        """
        self.targets = []
        for target in targets:
            target = target.expanduser()
            assert target.is_dir() or target.is_file()
            self.targets.append(target)

        self.exclude_dirs = exclude_dirs
        self.exclude_files = exclude_files
        self.include_files = include_files
        self.git_tracked = git_tracked
        self.empty = empty
        self.binary = binary
        self.max_depth = max_depth
        self.executable = executable
        self.also_dirs = also_dirs
        self.only_dirs = only_dirs
        self.size_bigger = size_bigger
        self.size_lower = size_lower
        self.changed_within = changed_within
        self.change_older_than = change_older_than

        self.sortspec = [] # List[sortspec] = List[Function, Bool]
        if sort is not None:
            for s in sort:
                self.sortspec.append(
                    {
                        Sort.ALPHA: (lambda path: path.name, False),
                        Sort.ALPHA_INV: (lambda path: path.name, True),
                        Sort.SIZE: (lambda path: path.stat().st_blocks, False),
                        Sort.SIZE_INV: (lambda path: path.stat().st_blocks, True),
                        Sort.MODIFICATION: (lambda path: path.stat().st_mtime, False),
                        Sort.MODIFICATION_INV: (
                            lambda path: path.stat().st_mtime,
                            True,
                        ),
                        Sort.DIRS_FIRST: (lambda path: path.is_dir(), True),
                        Sort.FILES_FIRST: (lambda path: path.is_dir(), False),
                    }[s]
                )

    def filter_file(self, path: Path) -> bool:
        """
        put costly checks at the end to save coputation time
        """
        if self.only_dirs:
            return True

        if self.include_files:
            if not any(path.match(f) for f in self.include_files):
                LOG.debug("Not in inclusion list %s", path)
                return True

        for excluded in self.exclude_files:
            if path.match(excluded):
                LOG.debug("Excluded %s by match %s", path, excluded)
                return True

        if self.empty is not None:
            is_empty = path.stat().st_size == 0

            if self.empty != is_empty:
                # equivalent to the condition: (self.empty and not is_empty) or (not self.empty and is_empty)
                LOG.debug("Excluded %s due to empty option", path)
                return True
        if self.size_bigger is not None:
            if path.stat().st_size <= self.size_bigger:
                return True
        if self.size_lower is not None:
            if path.stat().st_size >= self.size_lower:
                return True

        if self.executable is not None:
            # TODO: use https://docs.python.org/3/library/stat.html
            user_perm = int("{:o}".format(path.stat().st_mode)[-3])
            is_executable = user_perm & 0b001
            if self.executable != is_executable:
                LOG.debug("Excluded %s due to executable option", path)
                return True

        if self.changed_within is not None:
            age = calculate_modification_age(path)
            if age> self.changed_within:
                LOG.debug('Excluded %s due to its modification age %f', path, age)
                return True

        if self.change_older_than is not None:
            age = calculate_modification_age(path)
            if age< self.change_older_than:
                LOG.debug('Excluded %s due to its modification age %f', path, age)
                return True

        if self.binary is not None:
            is_binary = False
            try:
                path.read_text()
            except UnicodeError:
                is_binary = True
            if is_binary != self.binary:
                LOG.debug("Excluded %s due to binary option", path)
                return True

        return False

    def filter_dir(self, path: Path) -> bool:
        # path is folder
        for excluded in self.exclude_dirs:
            if path.match(excluded):
                LOG.debug("Excluded dir %s by  match %s", path, excluded)
                return True
        if self.max_depth is not None:
            if len(self.targets) > 1:
                # TODO: make it faster with a cached function
                root = next(r for r in self.targets if path.is_relative_to(r))
            else:
                root = self.targets[0]
            depth = (
                len(path.relative_to(root).parents) + 1
            )  # adds one to get the depth of its childrens
            if depth > self.max_depth:
                return True

        return False

    def filter(self, path: Path) -> bool:
        if path.is_file():
            return self.filter_file(path)
        elif path.is_dir() and path.is_symlink():
            LOG.debug("skipping symbolic folder %s", path)
            return True
        elif path.is_dir():
            return self.filter_dir(path)
        else:
            LOG.warning("unknown file type %s ", path)
            # could be:
            #  - broken symblink
            #  - char/block device
            #  - socket
            return True

    def _walk(self, path):
        if self.filter(path):
            return

        if path.is_file():
            yield path
            return

        assert path.is_dir()
        if self.only_dirs or self.also_dirs:
            yield path
        childs = list(path.iterdir())
        if self.sortspec is not None:
            for key, reverse in reversed(self.sortspec):
                # TODO: sort after filtering to save computation time
                childs.sort(key=key, reverse=reverse)
        for file in childs:
            yield from self._walk(file)

    def walk(self):
        for target in self.targets:
            yield from self._walk(target)

    def walk_git(self):
        """
        Other filters apply except those related to directories
        """
        for target in self.targets:
            file_list = subprocess.run(
                ["git", "-C", str(target), "ls-files", str(target)],
                capture_output=True,
                check=True,
            ).stdout
            # TODO: error will be printed? or only will CalledProcessError showing return value?

            for file in file_list.splitlines():
                file = target / Path(file.decode())
                assert file.is_file()
                if not self.filter(file):
                    yield file

def calculate_modification_age(path):
    modification_time = path.stat().st_mtime
    return datetime.now().timestamp() - modification_time

def walkfind(*targets: List[Path], **kwargs):  # TODO: accept targets: List[str] ?
    """
    Convenience function. For supported arguments see WalkFind.__init__
    """
    if len(targets) == 1 and str(targets[0]) == "-":
        for line in sys.stdin.readlines():
            yield line[:-1]  # strip readline
        return

    obj = WalkFind(targets, **kwargs)
    if obj.git_tracked:
        yield from obj.walk_git()
    else:
        yield from obj.walk()


def main():
    targets, options = get_arguments()
    for path in walkfind(*targets, **options):
        print(path)


if __name__ == "__main__":
    main()
